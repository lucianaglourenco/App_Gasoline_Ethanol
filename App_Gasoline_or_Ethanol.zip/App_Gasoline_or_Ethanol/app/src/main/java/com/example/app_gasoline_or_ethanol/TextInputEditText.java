package com.example.app_gasoline_or_ethanol;

public class TextInputEditText {
    public void setText(int resultTextEthanol) {
    }
}
